# Manifest: every file, where it came from, its SHA-256


| path | origin | sha256 |
|---|---|---|
| `README.md` | docs/f3/bundle/README.md | `b8ea9680bc885ab1e0c524d6f5991debda3628a963e318c4f3085e128742e8ea` |
| `REVIEW_TEMPLATE.md` | docs/f3/bundle/REVIEW_TEMPLATE.md | `8aea7b9dc168e2e63c5cdb5069d9c9244d56bbc4177001da5fb971a588d7193c` |
| `TIER_A_OUTPUT.txt` | docs/f3/bundle/TIER_A_OUTPUT.txt | `d75e2fac8b0e1269e94b891b2ec197b4916908ab9fbcb91789347330944e9489` |
| `challenge/f3/arms.py` | challenge/f3/arms.py | `e92ddca13aee8f57d3ea0b5049cda5c0ad252ba7017d1c0e3205482c548d5ca3` |
| `challenge/f3/baseline.py` | challenge/f3/baseline.py | `b7a31df1cabddad6f140d72c961cda0e43fb14aa70258ba408dba3f367cc58f2` |
| `challenge/f3/baseline_climbmix.py` | challenge/f3/baseline_climbmix.py | `b32a304cb39b5f3ffb9a847ab1b57c5d4a4dcc89d0fc0d67c7d7094b96f7f5aa` |
| `challenge/f3/climbmix_data.py` | challenge/f3/climbmix_data.py | `0b4c6586df27a3ba6af80bf387453cef7473b296d2c14159da463e9d84a964b5` |
| `challenge/f3/harness.py` | challenge/f3/harness.py | `f892414e0c6289b4ac4a30bf96154aedf0f60dfc1a7191af465e34073e0a543b` |
| `challenge/f3/pilot.py` | challenge/f3/pilot.py | `a9808439008119c20458537bd0ed5a0c7cda2fa2ea6718a3822b354af42adde7` |
| `challenge/f3/room_gate.py` | challenge/f3/room_gate.py | `e8d5d4469ac965b21e17a5d2f6646fcdad7591ad341b8e6bc928b2473bd0028e` |
| `challenge/f3/task.py` | challenge/f3/task.py | `68c470199adbd2e5e6b263f2d31f6fc24539c4cad9045033915afd65db6a643c` |
| `challenge/f3/task_climbmix.py` | challenge/f3/task_climbmix.py | `ab1166aa9c87970d460ee2c0dda3ce3ebc56e7c6523c349a506806842e375019` |
| `challenge/f3/task_spec.json` | challenge/f3/task_spec.json | `0c75ef9df6d4060441416ee7260b7125979669bcab98eddb482e8d7eb725ce57` |
| `challenge/f3/task_spec_gpu.json` | challenge/f3/task_spec_gpu.json | `1c298a1be73d68045bfaeeb74e470549add405fc1cf76569efb4f77af38553ed` |
| `challenge/f3/task_spec_gpu_mac.json` | challenge/f3/task_spec_gpu_mac.json | `e653148de315e3b3ad6dee27c3053e3edd7e1619879f816a7427537d8080c0cc` |
| `challenge/f3/task_spec_gpu_p2.json` | challenge/f3/task_spec_gpu_p2.json | `5cf50b5179d47f45e39af0e0c5029e11c710ff62a9f1c24abf71168019514cef` |
| `challenge/f3/verify.py` | challenge/f3/verify.py | `f973e7e283f1d9a4488b2cfe6430669b325c8c8caaa0d3fe2e24736b4b3b8149` |
| `check.sh` | docs/f3/bundle/check.sh | `759b6a2e0027e5cb965e3ad9aa95409679d6cfb51d5a435fd39c48f949181ca7` |
| `make_bundle.sh` | docs/f3/bundle/make_bundle.sh | `0f72fa68f2eeb43ead8215e91a54572ce4880ab27090bd10d5b70ecc2184abc9` |
| `protocol/PROTOCOL.current.md` | docs/f3/PROTOCOL.md (working tree; adds A5 and later text) | `b88d91490fdde4e6969ece9257084991bc8a3f196c7316774091ec465bb71b79` |
| `protocol/PROTOCOL.pilot1.md` | git show 0908479:docs/f3/PROTOCOL.md | `583fabc7caaa9d97defa6da8cb3b2baeb8497be9f5950cc56762325de1c0a69e` |
| `protocol/PROTOCOL.pilot2.md` | git show 0bb8968:docs/f3/PROTOCOL.md | `e7c3871a022dbde4258895f246aae44594a09bd5122991a0f42cc4fc166739c8` |
| `runs/pilot1/README.md` | docs/f3/pilot/README.md | `43b879f0800bf37307b50fab8533755b5a274ba17e25a254432cdde32d850e31` |
| `runs/pilot1/candidates/1b3df86124b6930b3a09c0cc673ccf5e365e26716b2e767fd75a7b9896f80b2f.py` | docs/f3/pilot/candidates/1b3df86124b6930b3a09c0cc673ccf5e365e26716b2e767fd75a7b9896f80b2f.py | `1b3df86124b6930b3a09c0cc673ccf5e365e26716b2e767fd75a7b9896f80b2f` |
| `runs/pilot1/candidates/314fc7977da064ad4128b4a31a18f8d7e66e055e6c8d1991e2344f80f82db0e6.py` | docs/f3/pilot/candidates/314fc7977da064ad4128b4a31a18f8d7e66e055e6c8d1991e2344f80f82db0e6.py | `314fc7977da064ad4128b4a31a18f8d7e66e055e6c8d1991e2344f80f82db0e6` |
| `runs/pilot1/candidates/39079932c004f0aa310e9e2942b2532f1550c488d9d9dd8de9dc45747b80dd58.py` | docs/f3/pilot/candidates/39079932c004f0aa310e9e2942b2532f1550c488d9d9dd8de9dc45747b80dd58.py | `39079932c004f0aa310e9e2942b2532f1550c488d9d9dd8de9dc45747b80dd58` |
| `runs/pilot1/candidates/556f1dd615667d7e48839b25832c15362bb876af5a6ba23435741a70d540f7e1.py` | docs/f3/pilot/candidates/556f1dd615667d7e48839b25832c15362bb876af5a6ba23435741a70d540f7e1.py | `556f1dd615667d7e48839b25832c15362bb876af5a6ba23435741a70d540f7e1` |
| `runs/pilot1/candidates/6a07d1d15a170cddbc7e913f3ab5d4722e5c7d68ed056a3419745ccd55400b76.py` | docs/f3/pilot/candidates/6a07d1d15a170cddbc7e913f3ab5d4722e5c7d68ed056a3419745ccd55400b76.py | `6a07d1d15a170cddbc7e913f3ab5d4722e5c7d68ed056a3419745ccd55400b76` |
| `runs/pilot1/candidates/a8c77fab8beb116051edd9f5f95b572630a6183d432780a957e1446235a6bdb2.py` | docs/f3/pilot/candidates/a8c77fab8beb116051edd9f5f95b572630a6183d432780a957e1446235a6bdb2.py | `a8c77fab8beb116051edd9f5f95b572630a6183d432780a957e1446235a6bdb2` |
| `runs/pilot1/candidates/b32a304cb39b5f3ffb9a847ab1b57c5d4a4dcc89d0fc0d67c7d7094b96f7f5aa.py` | docs/f3/pilot/candidates/b32a304cb39b5f3ffb9a847ab1b57c5d4a4dcc89d0fc0d67c7d7094b96f7f5aa.py | `b32a304cb39b5f3ffb9a847ab1b57c5d4a4dcc89d0fc0d67c7d7094b96f7f5aa` |
| `runs/pilot1/candidates/c38b570872a9028bf84d3d70339dcaa0b5a412b12f40f705aeba83489b5019eb.py` | docs/f3/pilot/candidates/c38b570872a9028bf84d3d70339dcaa0b5a412b12f40f705aeba83489b5019eb.py | `c38b570872a9028bf84d3d70339dcaa0b5a412b12f40f705aeba83489b5019eb` |
| `runs/pilot1/candidates/dcdacc9ecdfeb25e941fc950f260ed70a32f9b9555258db8ef5661c8bfdd4e62.py` | docs/f3/pilot/candidates/dcdacc9ecdfeb25e941fc950f260ed70a32f9b9555258db8ef5661c8bfdd4e62.py | `dcdacc9ecdfeb25e941fc950f260ed70a32f9b9555258db8ef5661c8bfdd4e62` |
| `runs/pilot1/feed.jsonl` | docs/f3/pilot/feed.jsonl | `982097f2dd9097de35a26251bfb1940d47863072ccd4bc3ea66eb34b7ab1db4f` |
| `runs/pilot1/host.pub` | docs/f3/pilot/host.pub | `7f3b8547ebea32d739139bfb4401d172d35f24061921eb5a7c0447209ecb7b33` |
| `runs/pilot1/init.log` | docs/f3/pilot/init.log | `402f524c150173743aaeae41a4a669e5e2bd659bb2d55b979aee5020e7088ef3` |
| `runs/pilot1/pilot.log` | docs/f3/pilot/pilot.log | `9831895ef0a479ed32d48b88e1b3de3cf6da31f74a748830aacbc270615100fc` |
| `runs/pilot1/pilot2.log` | docs/f3/pilot/pilot2.log | `ff3ff8a55412fefdf6093f475c135d14504d0d6e2e7fce07535da85ae867de3e` |
| `runs/pilot1/receipts.jsonl` | docs/f3/pilot/receipts.jsonl | `72484d98839cbca6f0dc21206a376fbe3131c57895b43f554bd0c1be88396bbb` |
| `runs/pilot1/verify.txt` | docs/f3/pilot/verify.txt | `84848f23cb400676b56acb4c4886a770054b8121f7009b111c809cbdd6d4469e` |
| `runs/pilot1/verify_replay.txt` | docs/f3/pilot/verify_replay.txt | `d96c0e254b58f84f6cf9d11e05f2fd2f98f6709401e8df053576196d0c357509` |
| `runs/pilot2/P2OUT_TGZ_SHA256.txt` | sha256 of docs/f3/pilot2/p2out.tgz, from which the files below were extracted unchanged | `9f3059b83a4e2eb3cdb3029ce299e218125e163d1324481ae24c985659abbeae` |
| `runs/pilot2/PINNED.txt` | docs/f3/pilot2/PINNED.txt | `67175fe1d5ea059517b87a8698fa02d2dcc951013a67d6334e520b854129bdb9` |
| `runs/pilot2/README.md` | docs/f3/pilot2/README.md | `a27acf30bc5c49da6f78501fac3a883dbdb693675cb0b0fb7dec2c407f54cb1f` |
| `runs/pilot2/arm.log` | docs/f3/pilot2/arm.log | `e386673c9e0df43695d8ab23945a8be9dd5e0a7baa47d39728827234b059c5f1` |
| `runs/pilot2/candidates/1cf676d369b5128838759274bff9702dc656abeb462fee49e2ffeabd8a8f68f8.py` | docs/f3/pilot2/p2out.tgz:candidates/1cf676d369b5128838759274bff9702dc656abeb462fee49e2ffeabd8a8f68f8.py | `1cf676d369b5128838759274bff9702dc656abeb462fee49e2ffeabd8a8f68f8` |
| `runs/pilot2/candidates/28bbf440e310b9dc608d5096b99f54a1909027c74dbcce61bee7ed06944e6d19.py` | docs/f3/pilot2/p2out.tgz:candidates/28bbf440e310b9dc608d5096b99f54a1909027c74dbcce61bee7ed06944e6d19.py | `28bbf440e310b9dc608d5096b99f54a1909027c74dbcce61bee7ed06944e6d19` |
| `runs/pilot2/candidates/783880e37d391eb847c50921d2f29c505bf23d9083127b3ed315e2c4b4ae148c.py` | docs/f3/pilot2/p2out.tgz:candidates/783880e37d391eb847c50921d2f29c505bf23d9083127b3ed315e2c4b4ae148c.py | `783880e37d391eb847c50921d2f29c505bf23d9083127b3ed315e2c4b4ae148c` |
| `runs/pilot2/candidates/9f9365321de649c971bbe7292efece3cbc3a9c6d297944b7516fb0926d77eb81.py` | docs/f3/pilot2/p2out.tgz:candidates/9f9365321de649c971bbe7292efece3cbc3a9c6d297944b7516fb0926d77eb81.py | `9f9365321de649c971bbe7292efece3cbc3a9c6d297944b7516fb0926d77eb81` |
| `runs/pilot2/candidates/b32a304cb39b5f3ffb9a847ab1b57c5d4a4dcc89d0fc0d67c7d7094b96f7f5aa.py` | docs/f3/pilot2/p2out.tgz:candidates/b32a304cb39b5f3ffb9a847ab1b57c5d4a4dcc89d0fc0d67c7d7094b96f7f5aa.py | `b32a304cb39b5f3ffb9a847ab1b57c5d4a4dcc89d0fc0d67c7d7094b96f7f5aa` |
| `runs/pilot2/feed.jsonl` | docs/f3/pilot2/p2out.tgz:feed.jsonl | `a9a68b9702de16aea4eda2c10af390f62baabdc0750dc608a5cbd55b655c17d8` |
| `runs/pilot2/host.pub` | docs/f3/pilot2/host.pub | `52c3d26e40875d58e50cfd96709418fadfdd5560c026f416de89e75cdd98a85e` |
| `runs/pilot2/receipts.jsonl` | docs/f3/pilot2/p2out.tgz:receipts.jsonl | `ad86d26dc0a7cc0bf598da41cb04ca9c3006a23f7c7c7a76c87d6bf4a80ecdc0` |
| `runs/pilot2/replay2.txt` | docs/f3/pilot2/replay2.txt | `b8d7da51ee309ebdb78ef482139f2a7a4bbe7bc793af1fac383006a1e0c28b8c` |
| `runs/pilot2/verify2.txt` | docs/f3/pilot2/verify2.txt | `c6e268761a81e65d2460e32e7e812782867826e472a2b477320df3146389fa77` |
| `runs/smoke_p2/README.md` | docs/f3/smoke_p2/README.md | `7d6b65bb7cdf788997e6a62877348ae6460c676ea4ba3de1a0b718a66bc51117` |
| `runs/smoke_p2/smoke_results.jsonl` | docs/f3/smoke_p2/smoke_results.jsonl | `d5081de4a9b9a10d9046b33886ab292c065fffbb6db7344e798fedc6b34355a8` |
